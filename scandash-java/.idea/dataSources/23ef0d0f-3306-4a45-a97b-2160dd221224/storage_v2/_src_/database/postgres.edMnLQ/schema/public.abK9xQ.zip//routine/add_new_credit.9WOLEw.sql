create function add_new_credit() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Add 5k to the card's storecredit
    UPDATE CARD
    SET storecredit = storecredit + 5000, 
        isActive = TRUE  -- Set card as active
    WHERE cardID = NEW.cardID;  -- Use NEW.cardID to reference the inserted row's cardID
    RETURN NEW;
END;
$$;

alter function add_new_credit() owner to postgres;

grant execute on function add_new_credit() to anon;

grant execute on function add_new_credit() to authenticated;

grant execute on function add_new_credit() to service_role;

