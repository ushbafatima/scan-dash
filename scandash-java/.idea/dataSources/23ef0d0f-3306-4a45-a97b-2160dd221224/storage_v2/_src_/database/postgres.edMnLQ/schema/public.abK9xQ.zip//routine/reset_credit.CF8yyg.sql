create function reset_credit() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Reset storecredit to 0 and set isActive to false
    UPDATE CARD
    SET storecredit = 0, 
        isActive = FALSE
    WHERE cardID = OLD.cardID;  -- Use OLD.cardID to reference the deleted row's cardID
    RETURN OLD;
END;
$$;

alter function reset_credit() owner to postgres;

grant execute on function reset_credit() to anon;

grant execute on function reset_credit() to authenticated;

grant execute on function reset_credit() to service_role;

