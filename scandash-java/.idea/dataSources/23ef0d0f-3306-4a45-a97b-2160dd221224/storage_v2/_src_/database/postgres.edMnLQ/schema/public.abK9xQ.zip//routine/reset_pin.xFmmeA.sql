create function reset_pin() returns trigger
    language plpgsql
as
$$BEGIN
    -- Set PIN to '0000' in CardCredentials table for the associated card
    IF OLD.cardID IS NOT NULL THEN
        UPDATE CardCredentials
        SET PIN = 'CXV6qZDXysw='
        WHERE CardID = OLD.cardID;
    END IF;
    RETURN OLD;
END;$$;

alter function reset_pin() owner to postgres;

grant execute on function reset_pin() to anon;

grant execute on function reset_pin() to authenticated;

grant execute on function reset_pin() to service_role;

