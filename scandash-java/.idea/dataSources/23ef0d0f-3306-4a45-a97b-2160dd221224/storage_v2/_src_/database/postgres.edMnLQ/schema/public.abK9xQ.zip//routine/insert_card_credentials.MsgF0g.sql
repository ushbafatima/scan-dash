create function insert_card_credentials() returns trigger
    language plpgsql
as
$$BEGIN
    -- Insert a new entry in CardCredentials with the CardID and default PIN
    INSERT INTO CardCredentials (CardID, PIN)
    VALUES (NEW.CardID, 'CXV6qZDXysw=');
    
    RETURN NEW;
END;$$;

alter function insert_card_credentials() owner to postgres;

grant execute on function insert_card_credentials() to anon;

grant execute on function insert_card_credentials() to authenticated;

grant execute on function insert_card_credentials() to service_role;

