create function activate_card() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the card's isActive status to TRUE
    UPDATE Card
    SET isActive = TRUE
    WHERE cardID = NEW.cardID;
    RETURN NEW;
END;
$$;

alter function activate_card() owner to postgres;

grant execute on function activate_card() to anon;

grant execute on function activate_card() to authenticated;

grant execute on function activate_card() to service_role;

