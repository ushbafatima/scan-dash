create function deactivate_card() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the corresponding card to set isActive to false
    UPDATE CARD
    SET isActive = FALSE
    WHERE cardID = OLD.cardID;  -- OLD.cardID refers to the cardID of the deleted customer

    RETURN OLD;  -- Return the old row (deleted customer) to complete the delete operation
END;
$$;

alter function deactivate_card() owner to postgres;

grant execute on function deactivate_card() to anon;

grant execute on function deactivate_card() to authenticated;

grant execute on function deactivate_card() to service_role;

